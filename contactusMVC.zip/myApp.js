const express = require('express');
const myApp = express();
const port = 5000;

// Set the views directory
myApp.set('views', __dirname + '/views');

// Set the view engine
myApp.set('view engine', 'html');

// Routes
myApp.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/index.html');
});

// Controller for Contact Us route
myApp.get('/contactus', (req, res) => {
  res.sendFile('contactus.html', { root: './views' });
});

myApp.post('/contactus', (req, res) => {
  // Handle form submission
  // Logic to process the form data and save it
  // Redirect to success page
  res.redirect('/success');
});

// Controller for Success route
myApp.get('/success', (req, res) => {
  res.sendFile(__dirname + '/public/success.html');
});

myApp.post('/success', (req, res) => {
  // Handle the POST request to /success
  // Logic to process the form submission success
  // Redirect or render a success page
  res.send('Form submission successful');
});

// Start the server
myApp.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
