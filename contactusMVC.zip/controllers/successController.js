const path = require('path');

// Handle GET request for /success route
function getSuccess(req, res) {
  res.sendFile(path.join(__dirname, '../views/success.html'));
}

// Export the controller function
module.exports = {
  getSuccess,
};
